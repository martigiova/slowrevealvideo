Slow Reveal Video - Portable Bundle
===================================

This bundle contains the SlowReveal batch processor (Tkinter UI) plus helper launchers. Python 3.10+ must be available on the machine (https://www.python.org/downloads/). ffmpeg must also be installed separately and reachable via PATH.

How to run on Windows
---------------------
1. Double-click "Start SlowRevealVideo.bat" (or run it from a terminal).
2. The script creates a local virtual environment in .venv, installs dependencies from requirements.txt, then launches the GUI.
3. The first run may take a couple of minutes while pip downloads MoviePy and friends. Subsequent launches reuse the cached environment.

How to run on macOS
-------------------
1. Open Terminal, navigate to this folder, and run: `chmod +x Start\ SlowRevealVideo.command` (first time only).
2. Double-click the command file (or execute `./Start\ SlowRevealVideo.command`), which provisions a .venv and starts the GUI.

Tip: keep ffmpeg.exe / ffmpeg binary in PATH or copy it next to the folder to avoid runtime errors.
