Slow Reveal Video – Portable Bundle
===================================

This folder contains the SlowReveal batch processor, launcher scripts, and all project files.
You still need a system Python 3.10+ installation and an `ffmpeg` binary reachable from PATH.

How to launch on Windows
------------------------
1. Double-click `Start SlowRevealVideo.bat`.
2. The script provisions `.venv` (if missing), installs dependencies via that interpreter, then starts the GUI.
3. If you see a Windows SmartScreen warning, choose “More info → Run anyway”.

How to launch on macOS
----------------------
1. Open Terminal, run `chmod +x "Start SlowRevealVideo.command"` once, then double-click it.
2. The script provisions `.venv`, installs dependencies with the venv’s Python, and launches the GUI.
3. Stay in that folder while the app runs so it can resolve the bundled package.

Tip: Keep `ffmpeg` in PATH (or next to the folder) to avoid runtime encoding errors.
