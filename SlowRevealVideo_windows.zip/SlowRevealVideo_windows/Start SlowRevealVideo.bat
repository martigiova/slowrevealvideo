@echo off
setlocal
cd /d %~dp0

where py >nul 2>nul
if %errorlevel%==0 (
    set PY_CMD=py -3.10
) else (
    set PY_CMD=python
)

if not exist .venv (
    echo [SlowReveal] Creating virtual environment...
    %PY_CMD% -m venv .venv || goto :error
)

call .venv\Scripts\activate.bat
python -m pip install --upgrade pip >nul
python -m pip install -r requirements.txt || goto :error
python -m slowreveal
exit /b 0

:error
echo Failed to start SlowRevealVideo. Ensure Python 3.10+ and ffmpeg are installed.
pause
exit /b 1
