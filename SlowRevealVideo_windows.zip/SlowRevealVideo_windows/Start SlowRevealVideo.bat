@echo off
setlocal enabledelayedexpansion
cd /d %~dp0

set PYTHON_BIN=
where py >nul 2>nul && for /f "delims=" %%i in ('py -3.10 -c "import sys; print(sys.executable)" 2^>nul') do set PYTHON_BIN=py -3.10
if not defined PYTHON_BIN (
    where py >nul 2>nul && for /f "delims=" %%i in ('py -3.11 -c "import sys; print(sys.executable)" 2^>nul') do set PYTHON_BIN=py -3.11
)
if not defined PYTHON_BIN (
    where python3 >nul 2>nul && set PYTHON_BIN=python3
)
if not defined PYTHON_BIN (
    where python >nul 2>nul && set PYTHON_BIN=python
)

if not defined PYTHON_BIN (
    echo Could not find Python 3.10+. Install it from https://www.python.org/downloads/ and try again.
    pause
    exit /b 1
)

if not exist .venv (
    echo [SlowReveal] Creating virtual environment with %PYTHON_BIN% ...
    %PYTHON_BIN% -m venv .venv || goto :error
)

set VENV_PY=%CD%\.venv\Scripts\python.exe
if not exist "%VENV_PY%" (
    echo Could not locate %VENV_PY%. Delete .venv and rerun.
    pause
    exit /b 1
)

"%VENV_PY%" -m pip install --upgrade pip setuptools wheel || goto :error
"%VENV_PY%" -m pip install --upgrade -r requirements.txt || goto :error
"%VENV_PY%" -m slowreveal || goto :error
exit /b 0

:error
echo Failed to start SlowRevealVideo. Ensure Python 3.10+ and ffmpeg are installed.
pause
exit /b 1
