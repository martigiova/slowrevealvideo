#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

PYTHON_BIN="python3"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python3 not found. Install Python 3.10+ first." >&2
  read -p "Press Enter to exit" _
  exit 1
fi

if [ ! -d .venv ]; then
  echo "[SlowReveal] Creating virtual environment..."
  "$PYTHON_BIN" -m venv .venv
fi

source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m slowreveal
