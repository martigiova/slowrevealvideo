#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

PYTHON_BIN=${PYTHON_BIN:-python3}
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "Python 3.10+ not found. Install it from https://www.python.org/downloads/ first."
  read -p "Press Enter to exit" _
  exit 1
fi

if [ ! -d .venv ]; then
  echo "[SlowReveal] Creating virtual environment with $PYTHON_BIN ..."
  "$PYTHON_BIN" -m venv .venv
fi

VENV_PY="$PWD/.venv/bin/python3"
if [ ! -x "$VENV_PY" ]; then
  VENV_PY="$PWD/.venv/bin/python"
fi
if [ ! -x "$VENV_PY" ]; then
  echo "Could not locate the virtualenv python interpreter. Delete .venv and rerun."
  read -p "Press Enter to exit" _
  exit 1
fi

"$VENV_PY" -m pip install --upgrade pip setuptools wheel
"$VENV_PY" -m pip install --upgrade -r requirements.txt
"$VENV_PY" -m slowreveal
